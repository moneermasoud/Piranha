﻿Imports System.Net
Imports System.Web
Imports System.IO
Imports System.Net.Mail

Public Class main
    '# I know what you think :) 
    '# you can access the API using curl, a web browser or a scripting language of your choice such as php or python.

    Public api_link As String
    Private Sub main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Clipboard.SetText(Output.Text)
    End Sub


    Public Function Send_request_to_api(api_link) As String

        Dim uri_val As New Uri(api_link)
        Dim request As Net.HttpWebRequest = Net.HttpWebRequest.Create(uri_val)

        request.Method = WebRequestMethods.Http.Get

        Dim response As HttpWebResponse = request.GetResponse()
        Dim reader As New StreamReader(response.GetResponseStream())
        Dim rezlt As String = reader.ReadToEnd()

        response.Close()

        Return rezlt

    End Function


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If target.Text = vbNullString Or CB_option.Text = vbNullString Then
            MsgBox("Please Enter ip or domain and Choose on List", MsgBoxStyle.Information, "Error")
            Exit Sub
        End If

        Try
            If CB_option.Text = "Reverse IP Lookup" Then
                Output.Clear()
                api_link = "https://api.hackertarget.com/reverseiplookup/?q=" & target.Text
                Output.Text = Send_request_to_api(api_link)
            End If

            If CB_option.Text = "TCP Port Scan" Then
                Output.Clear()
                api_link = "https://api.hackertarget.com/nmap/?q=" & target.Text
                Output.Text = Send_request_to_api(api_link)
            End If

            If CB_option.Text = "DNS Lookup" Then
                Output.Clear()
                api_link = "https://api.hackertarget.com/dnslookup/?q=" & target.Text
                Output.Text = Send_request_to_api(api_link)
            End If

            If CB_option.Text = "Reverse DNS Lookup" Then
                Output.Clear()
                api_link = "https://api.hackertarget.com/reversedns/?q=" & target.Text
                Output.Text = Send_request_to_api(api_link)
            End If

            If CB_option.Text = "Whois Lookup" Then
                Output.Clear()
                api_link = "https://api.hackertarget.com/whois/?q=" & target.Text
                Output.Text = Send_request_to_api(api_link)
            End If

            If CB_option.Text = "Lookup Subdomains" Then
                Output.Clear()
                api_link = "https://api.hackertarget.com/hostsearch/?q=" & target.Text
                Output.Text = Send_request_to_api(api_link)
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        target.Clear()
        Output.Clear()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        about.Show()
    End Sub


End Class
