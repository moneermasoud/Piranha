﻿Public Class about

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click
        Close()
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        Process.Start("https://github.com/moneermasoud")
    End Sub
End Class